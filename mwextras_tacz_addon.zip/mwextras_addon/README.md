# MW Extras - TaCZ addon (Forge 1.20.1)  v1.1

## Items
| item | how it works |
|---|---|
| Throwing Knife | Right click: wind-up, then it leaves the hand. Tumbles, sticks in blocks, pick it up again. Headshots hit harder. Flip-up draw animation, camera kick on throw. |
| Armor Plate | Hold right click: unzip -> plate slides in -> zip. Bar under your hearts (3 plates). Each TaCZ bullet hit shatters one plate. |
| Demolition Charge | Aim at the TOP of a block, hold right click ~3.2 s (keypad beeps, you are rooted, camera dips). Bomb is armed, 3D model with a live countdown, beeps faster, explodes after 60 s. |
| Defuse Kit | Stand within ~3 blocks of the bomb, hold right click 5 s. Wire clicks, final snap, bomb powers down. Cancel by moving away. |
| Scorestreak cards | Given automatically when you hit the kill streak. See below. |

## Scorestreaks (kill streak, resets when you die)
| streak | kills | key (rebindable) | effect |
|---|---|---|---|
| UAV | 3 | Z | enemies (players + hostile mobs) within 96 blocks glow for 20 s |
| Care Package | 5 | X | smoke marker, then a crate (barrel) lands in front of you with plates, knives, food |
| Cluster Strike | 7 | C | aim at a spot: marker + whistle, then 7 explosions around it |

Right-click the card OR press the key. Right-side panel shows each streak (kills needed / READY / USED);
banner + radio callout when one unlocks or goes online. Each streak can be used once per life.
Hostile mob kills count too (config: streakCountMobs).

## Build
Easiest on a phone: GitHub Actions (see chat instructions). On a PC: install JDK 17, copy `gradlew`,
`gradlew.bat` and `gradle/` from the Forge 1.20.1 MDK (47.3.0) here, run `./gradlew build`.
Output: `build/libs/mwextras-1.1.0.jar`. Remove the old 1.0.0 jar from your mods folder.

## Config  (`config/mwextras-common.toml`)
plateAbsorb, maxPlates, plateUseTicks, knifeDamage, knifeCooldownTicks, bombFuseTicks (1200 = 60 s),
bombPlantTicks, bombDefuseTicks, bombExplosionPower, bombDestroysBlocks, uavRange, uavSeconds,
clusterStrikeDestroysBlocks, streakCountMobs, absorbAnyProjectile.

## Assets
`python3 tools/generate_assets.py && python3 tools/generate_assets_v2.py` rebuilds all textures, 3D models,
icons and sounds (needs numpy, scipy, Pillow, ffmpeg with libvorbis + flite). All original/procedural.
The voicelines are synthesized robotic radio calls. To use your own recordings, replace the .ogg files in
`assets/mwextras/sounds/voice/` (keep the same file names).
