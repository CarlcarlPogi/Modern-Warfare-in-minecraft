#!/usr/bin/env python3
"""
Generates every non-code asset for the MW Extras addon:
  * textures/item/throwing_knife.png, armor_plate.png   (128x128, painted procedurally)
  * models/item/throwing_knife.json, armor_plate.json   (multi-element 3D item models)
  * sounds/**/*.ogg                                     (synthesized zip/unzip/plate/knife SFX)

Needs: numpy, scipy, Pillow, ffmpeg (with libvorbis) on PATH.
Run from the project root:  python3 tools/generate_assets.py
Everything here is original / procedural -- no game assets are copied.
"""
import json, os, subprocess, sys, tempfile
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from scipy import signal
from scipy.io import wavfile

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "assets", "mwextras")
ROOT = os.path.normpath(ROOT)
rng = np.random.default_rng(1337)


# =====================================================================
# TEXTURES
# =====================================================================
def noise2(h, w, s): return rng.normal(0, s, (h, w))

def new_atlas(size=128):
    img = np.zeros((size, size, 4), np.float32)
    img[..., 3] = 255
    img[..., :3] = 60
    return img

def blit(img, x0, y0, arr):
    h, w = arr.shape[:2]
    img[y0:y0 + h, x0:x0 + w, :3] = np.clip(arr, 0, 255)

def tint(v, r=1.0, g=1.0, b=1.0):
    return np.stack([v * r, v * g, v * b], axis=-1)

def save_png(img, rel):
    path = os.path.join(ROOT, rel)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    Image.fromarray(np.clip(img, 0, 255).astype(np.uint8), "RGBA").save(path)
    return path


def make_knife_texture():
    img = new_atlas()

    # ---- blade (24 x 128 px, UV 0,0 -> 3,16). Tip at the TOP, sharpened edge on the LEFT. ----
    bw, bh = 24, 128
    yy, xx = np.mgrid[0:bh, 0:bw].astype(np.float32)
    v = np.full((bh, bw), 64.0)                     # blackened / parkerized steel
    v += np.clip(1 - xx / 5.0, 0, 1) ** 1.3 * 150   # bright sharpened bevel
    v[:, 5:7] -= 14                                  # grind line
    fuller = (xx >= 11) & (xx <= 15) & (yy >= 22) & (yy <= 104)
    v[fuller] -= 24                                  # fuller (blood groove)
    v[(xx == 11) & (yy >= 22) & (yy <= 104)] += 34
    v[(xx == 15) & (yy >= 22) & (yy <= 104)] += 18
    v[:, 20:] += 8
    v[:, 23] -= 22                                   # dark spine
    v += noise2(bh, bw, 3) + np.tile(rng.normal(0, 4, (1, bw)), (bh, 1))   # brushed streaks
    for _ in range(30):                              # edge wear / scratches
        x = rng.integers(1, bw - 1); y = rng.integers(0, bh - 14); L = rng.integers(4, 15)
        v[y:y + L, x] += rng.uniform(14, 42)
    for _ in range(40):                              # micro chips along the edge
        x = rng.integers(0, 4); y = rng.integers(0, bh)
        v[y, x] += 60
    blit(img, 0, 0, tint(v, 0.96, 0.99, 1.05))

    # ---- sharpened-edge tile (16x16 @ 32,0) ----
    e = np.full((16, 16), 208.0) + np.tile(rng.normal(0, 7, (1, 16)), (16, 1)) + noise2(16, 16, 3)
    blit(img, 32, 0, tint(e, 0.97, 0.99, 1.03))

    # ---- dark metal tile (16x16 @ 32,16): guard + pommel, cerakote w/ wear ----
    d = np.full((16, 16), 50.0) + noise2(16, 16, 5)
    for _ in range(10):
        d[rng.integers(0, 16), rng.integers(0, 16)] += rng.uniform(25, 55)
    blit(img, 32, 16, tint(d, 0.98, 1.0, 1.04))

    # ---- grip tile (32x32 @ 32,32): diamond-cut rubber, olive-black ----
    gy, gx = np.mgrid[0:32, 0:32]
    diamond = (((gx + gy) % 6) < 1) | (((gx - gy) % 6) < 1)
    g = np.where(diamond, 62.0, 30.0) + noise2(32, 32, 2.5)
    blit(img, 32, 32, tint(g, 1.0, 1.06, 0.86))

    return save_png(img, "textures/item/throwing_knife.png"), img


def hex_border(x, y, s):
    q = (np.sqrt(3) / 3 * x - 1 / 3 * y) / s
    r = (2 / 3 * y) / s
    cx, cz = q, r
    cy = -cx - cz
    rx, ry, rz = np.round(cx), np.round(cy), np.round(cz)
    d = np.maximum.reduce([np.abs(rx - cx), np.abs(ry - cy), np.abs(rz - cz)])
    return d


def make_plate_texture():
    img = new_atlas()

    # ---- front (64 x 88 px @ 0,0 -> UV 0,0..8,11): ballistic ceramic w/ hex pattern ----
    fw, fh = 64, 88
    yy, xx = np.mgrid[0:fh, 0:fw].astype(np.float32)
    base = 46.0 + (1 - yy / fh) * 10 + noise2(fh, fw, 2.2)
    d = hex_border(xx, yy, 6.5)
    base += np.where(d > 0.40, 20.0, 0.0)                 # hex grout lines
    base += np.where(d < 0.10, 5.0, 0.0)                  # raised centre of each tile
    # coated rim, inset 4px, with bevel
    edge = np.minimum.reduce([xx, yy, fw - 1 - xx, fh - 1 - yy])
    base_rgb = tint(base, 0.98, 1.0, 1.04)
    rim = edge < 4
    base_rgb[rim] = tint(86.0 + noise2(fh, fw, 3), 1.0, 0.95, 0.72)[rim]     # olive-drab coated rim
    base_rgb[edge == 4] = (150, 136, 98)                                      # bright inner rim line
    base_rgb[edge == 0] = (24, 26, 22)
    # wear
    for _ in range(26):
        x = rng.integers(2, fw - 2); y = rng.integers(2, fh - 8); L = rng.integers(3, 9)
        base[y:y + L, x] += rng.uniform(20, 50)
    pil = Image.fromarray(np.clip(base_rgb, 0, 255).astype(np.uint8), "RGB")
    dr = ImageDraw.Draw(pil)
    dr.rectangle([10, 34, fw - 11, 56], fill=(168, 148, 104), outline=(96, 84, 58))    # tan label
    try:
        font = ImageFont.load_default(size=11)
    except TypeError:
        font = ImageFont.load_default()
    dr.text((fw // 2, 38), "LVL IV", fill=(30, 26, 18), font=font, anchor="mt")
    dr.text((fw // 2, 49), "SAPI", fill=(48, 42, 30), font=font, anchor="mt")
    blit(img, 0, 0, np.asarray(pil, np.float32))

    # ---- back (64 x 88 px @ 64,16 -> UV 8,2..16,13): olive ripstop carrier ----
    by, bx = np.mgrid[0:88, 0:64].astype(np.float32)
    back = 74.0 + noise2(88, 64, 2.5)
    back[(bx % 4 == 0) | (by % 4 == 0)] -= 10
    rimb = np.minimum.reduce([bx, by, 63 - bx, 87 - by])
    back = np.where(rimb < 3, 50.0, back)
    img_b = tint(back, 0.92, 1.0, 0.72)
    blit(img, 64, 16, img_b)

    # ---- edge tile (16x16 @ 64,0): coated edge ----
    et = np.full((16, 16), 36.0) + noise2(16, 16, 3)
    blit(img, 64, 0, tint(et, 1.0, 1.02, 0.95))

    return save_png(img, "textures/item/armor_plate.png"), img


# =====================================================================
# MODELS
# =====================================================================
def faces_all(tex, uv):
    return {f: {"uv": [round(c, 3) for c in uv], "texture": tex} for f in ("north", "south", "east", "west", "up", "down")}

def rnd(v): return [round(x, 3) for x in v]

def blade_segments(blade_seg):
    """Full-width ricasso, then a curved clip-point taper built from thin steps (spine stays straight)."""
    segs = [blade_seg("blade_1", 6.9, 9.1, 7.4, 11.4)]
    n, y0, y1 = 12, 11.4, 19.3
    for i in range(n):
        ya = y0 + (y1 - y0) * i / n
        yb = y0 + (y1 - y0) * (i + 1) / n
        p = ((ya + yb) / 2 - y0) / (y1 - y0)
        xl = min(6.9 + 2.2 * (p ** 1.55), 9.1 - 0.22)
        segs.append(blade_seg("blade_%d" % (i + 2), round(xl, 2), 9.1, ya, yb))
    return segs

def make_knife_model():
    # Blade region in UV space (0,0)-(3,16) covers x 6.9..9.1 , y 7.4..19.3 (before centring shift)
    BX1, BX2, BY1, BY2 = 6.9, 9.1, 7.4, 19.3
    u = lambda x: (x - BX1) / (BX2 - BX1) * 3.0
    v = lambda y: (BY2 - y) / (BY2 - BY1) * 16.0
    EDGE = [4, 0, 5.5, 1.5]
    DARK = [4, 2, 5.5, 3.5]
    GRIP_SIDE = [4, 4, 5.5, 8]
    GRIP_CAP = [4, 4, 5.5, 5.5]

    def blade_seg(name, x1, x2, y1, y2):
        z1, z2 = 7.55, 8.45
        return {
            "name": name, "frm": [x1, y1, z1], "to": [x2, y2, z2],
            "faces": {
                "south": {"uv": [u(x1), v(y2), u(x2), v(y1)], "texture": "#0"},
                "north": {"uv": [u(x2), v(y2), u(x1), v(y1)], "texture": "#0"},
                "east":  {"uv": EDGE, "texture": "#0"}, "west": {"uv": EDGE, "texture": "#0"},
                "up":    {"uv": EDGE, "texture": "#0"}, "down": {"uv": EDGE, "texture": "#0"},
            }}

    def solid(name, frm, to, uvs):
        return {"name": name, "frm": frm, "to": to,
                "faces": {"north": {"uv": uvs[0], "texture": "#0"}, "south": {"uv": uvs[0], "texture": "#0"},
                          "east": {"uv": uvs[0], "texture": "#0"}, "west": {"uv": uvs[0], "texture": "#0"},
                          "up": {"uv": uvs[1], "texture": "#0"}, "down": {"uv": uvs[1], "texture": "#0"}}}

    els = [
        solid("pommel",  [6.8, -1.0, 7.0], [9.2, 0.4, 9.0], (DARK, DARK)),
        solid("grip_low",[7.0, 0.4, 7.1],  [9.0, 2.4, 8.9], (GRIP_SIDE, GRIP_CAP)),
        solid("grip_mid",[7.2, 2.4, 7.3],  [8.8, 4.8, 8.7], (GRIP_SIDE, GRIP_CAP)),
        solid("grip_up", [7.1, 4.8, 7.2],  [8.9, 6.6, 8.8], (GRIP_SIDE, GRIP_CAP)),
        solid("guard",   [6.5, 6.6, 7.0],  [9.5, 7.4, 9.0], (DARK, DARK)),
        *blade_segments(blade_seg),
        *[solid("jimping_%d" % i, [9.1, 7.5 + 0.4 * i, 7.7], [9.3, 7.5 + 0.4 * i + 0.22, 8.3], (DARK, DARK)) for i in range(5)],
        solid("lanyard_l", [6.9, -2.6, 7.6], [7.3, -1.0, 8.4], (DARK, DARK)),
        solid("lanyard_r", [8.7, -2.6, 7.6], [9.1, -1.0, 8.4], (DARK, DARK)),
        solid("lanyard_b", [6.9, -2.6, 7.6], [9.1, -2.2, 8.4], (DARK, DARK)),
    ]
    shift = 8.0 - ((19.3 + -2.6) / 2.0)   # centre the knife on (8,8,8) so it spins about its middle
    out = []
    for e in els:
        f, t = list(e["frm"]), list(e["to"])
        f[1] += shift; t[1] += shift
        out.append({"name": e["name"], "from": rnd(f), "to": rnd(t),
                    "faces": {k: {"uv": rnd(val["uv"]), "texture": val["texture"]} for k, val in e["faces"].items()}})

    model = {
        "credit": "Procedurally generated by tools/generate_assets.py",
        "texture_size": [128, 128],
        "textures": {"0": "mwextras:item/throwing_knife", "particle": "mwextras:item/throwing_knife"},
        "elements": out,
        "display": {
            "gui": {"rotation": [0, 0, -45], "translation": [0, 0, 0], "scale": [0.95, 0.95, 0.95]},
            "ground": {"rotation": [0, 0, 0], "translation": [0, 2, 0], "scale": [0.6, 0.6, 0.6]},
            "fixed": {"rotation": [0, 0, 0], "translation": [0, 0, 0], "scale": [1, 1, 1]},
            "thirdperson_righthand": {"rotation": [0, -90, 55], "translation": [0, 4, 0.5], "scale": [0.85, 0.85, 0.85]},
            "thirdperson_lefthand": {"rotation": [0, 90, -55], "translation": [0, 4, 0.5], "scale": [0.85, 0.85, 0.85]},
            "firstperson_righthand": {"rotation": [0, -90, 25], "translation": [1.13, 3.2, 1.13], "scale": [0.7, 0.7, 0.7]},
            "firstperson_lefthand": {"rotation": [0, 90, -25], "translation": [1.13, 3.2, 1.13], "scale": [0.7, 0.7, 0.7]},
        },
        "gui_light": "front",
    }
    return model


def make_plate_model():
    # front region UV (0,0)-(8,11) covers x 3..13 , y 0.3..14.0 ; back region UV (8,2)-(16,13)
    X1, X2, Y1, Y2 = 3.0, 13.0, 0.3, 14.0
    fu = lambda x: (x - X1) / (X2 - X1) * 8.0
    fv = lambda y: (Y2 - y) / (Y2 - Y1) * 11.0
    bu = lambda x: 8.0 + (x - X1) / (X2 - X1) * 8.0
    bv = lambda y: 2.0 + (Y2 - y) / (Y2 - Y1) * 11.0
    EDGE = [8, 0, 9.5, 1.5]
    z1, z2 = 7.2, 8.8

    def seg(name, x1, x2, y1, y2):
        return {
            "name": name, "from": rnd([x1, y1, z1]), "to": rnd([x2, y2, z2]),
            "faces": {
                "south": {"uv": rnd([fu(x1), fv(y2), fu(x2), fv(y1)]), "texture": "#0"},   # front
                "north": {"uv": rnd([bu(x2), bv(y2), bu(x1), bv(y1)]), "texture": "#0"},   # back (mirrored)
                "east": {"uv": EDGE, "texture": "#0"}, "west": {"uv": EDGE, "texture": "#0"},
                "up": {"uv": EDGE, "texture": "#0"}, "down": {"uv": EDGE, "texture": "#0"},
            }}

    els = [
        seg("body",       3.0, 13.0, 2.0, 11.5),
        seg("shoulders",  3.6, 12.4, 11.5, 13.0),
        seg("top",        5.2, 10.8, 13.0, 14.0),
        seg("lower",      3.6, 12.4, 1.0, 2.0),
        seg("bottom",     5.0, 11.0, 0.3, 1.0),
    ]
    return {
        "credit": "Procedurally generated by tools/generate_assets.py",
        "texture_size": [128, 128],
        "textures": {"0": "mwextras:item/armor_plate", "particle": "mwextras:item/armor_plate"},
        "elements": els,
        "display": {
            "gui": {"rotation": [8, -24, 0], "translation": [0, 0, 0], "scale": [1.05, 1.05, 1.05]},
            "ground": {"rotation": [0, 0, 0], "translation": [0, 2, 0], "scale": [0.6, 0.6, 0.6]},
            "fixed": {"rotation": [0, 180, 0], "translation": [0, 0, 0], "scale": [0.9, 0.9, 0.9]},
            "thirdperson_righthand": {"rotation": [0, 90, 0], "translation": [0, 3, 1], "scale": [0.65, 0.65, 0.65]},
            "thirdperson_lefthand": {"rotation": [0, -90, 0], "translation": [0, 3, 1], "scale": [0.65, 0.65, 0.65]},
            "firstperson_righthand": {"rotation": [-12, -62, 5], "translation": [1.5, 2, 1], "scale": [0.8, 0.8, 0.8]},
            "firstperson_lefthand": {"rotation": [-12, 62, -5], "translation": [-1.5, 2, 1], "scale": [0.8, 0.8, 0.8]},
        },
        "gui_light": "front",
    }


def write_json(rel, data):
    path = os.path.join(ROOT, rel)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, indent=2)


def preview(model, atlas, path, scale=14, face="south"):
    """Flat front-view render of the model by sampling its UVs -- a sanity check for the mapping."""
    W = 24 * scale; off = 4 * scale
    canvas = Image.new("RGB", (W, W), (36, 40, 46))
    px = canvas.load()
    S = atlas.shape[0]
    for e in model["elements"]:
        (x1, y1, z1), (x2, y2, z2) = e["from"], e["to"]
        u1, v1, u2, v2 = e["faces"][face]["uv"]
        for sy in range(int(y1 * scale), int(y2 * scale)):
            for sx in range(int(x1 * scale), int(x2 * scale)):
                fx = (sx / scale - x1) / (x2 - x1)
                fy = 1 - (sy / scale - y1) / (y2 - y1)
                u = (u1 + (u2 - u1) * fx) / 16 * S
                v = (v1 + (v2 - v1) * fy) / 16 * S
                c = atlas[int(np.clip(v, 0, S - 1)), int(np.clip(u, 0, S - 1)), :3]
                px[sx + off, W - off - sy - 1] = tuple(int(k) for k in c)
    canvas.save(path)


# =====================================================================
# SOUNDS
# =====================================================================
SR = 44100

def T(d): return np.arange(int(SR * d)) / SR
def noise(n): return rng.uniform(-1, 1, n)
def bp(x, lo, hi): return signal.sosfilt(signal.butter(2, [lo, hi], btype="band", fs=SR, output="sos"), x)
def hp(x, f): return signal.sosfilt(signal.butter(2, f, btype="high", fs=SR, output="sos"), x)
def lp(x, f): return signal.sosfilt(signal.butter(2, f, btype="low", fs=SR, output="sos"), x)
def add(buf, snd, at):
    i = int(at * SR)
    if i >= len(buf): return
    n = min(len(snd), len(buf) - i)
    buf[i:i + n] += snd[:n]
def ring(freq, decay, dur, amp=1.0):
    t = T(dur); return amp * np.sin(2 * np.pi * freq * t) * np.exp(-t / decay)
def sweep(f0, f1, dur, decay, amp=1.0):
    t = T(dur); f = f0 + (f1 - f0) * (t / dur)
    ph = 2 * np.pi * np.cumsum(f) / SR
    return amp * np.sin(ph) * np.exp(-t / decay)
def fade(x, a=0.01, r=0.03):
    n = len(x); na, nr = int(a * SR), int(r * SR)
    env = np.ones(n); env[:na] = np.linspace(0, 1, na); env[-nr:] = np.linspace(1, 0, nr)
    return x * env

def zipper(dur, rate0, rate1, f0, f1, level=1.0):
    """A run of metal teeth clicks + slider rattle. Rate ramps up for zipping, down for unzipping."""
    buf = np.zeros(int(SR * (dur + 0.15)))
    t = 0.0
    while t < dur:
        p = t / dur
        rate = rate0 + (rate1 - rate0) * p
        f = (f0 + (f1 - f0) * p) * rng.uniform(0.85, 1.25)
        c = ring(f, 0.0016, 0.014, rng.uniform(0.55, 1.0))
        n = int(SR * 0.007)
        c[:n] += 0.7 * hp(noise(n), 2500) * np.exp(-np.linspace(0, 1, n) * 6)
        add(buf, c, t)
        t += (1.0 / rate) * rng.uniform(0.78, 1.22)
    tt = T(dur + 0.15)
    mod = 0.65 + 0.35 * np.sin(2 * np.pi * ((rate0 + rate1) / 2) * tt)
    rattle = bp(noise(len(buf)), 650, 2600) * 0.16 * mod
    cloth = bp(noise(len(buf)), 180, 900) * 0.10
    return fade((buf + rattle + cloth) * level, 0.01, 0.05)

def make_unzip():
    z = zipper(1.0, 56, 40, 3100, 2300)
    buf = np.zeros(len(z) + int(SR * 0.1))
    add(buf, z, 0.06)
    add(buf, ring(3300, 0.012, 0.08, 0.7) + ring(5100, 0.008, 0.08, 0.4), 0.0)   # tab clink as it is grabbed
    add(buf, ring(240, 0.02, 0.1, 0.35), 1.02)                                       # tab drops
    return buf

def make_zip():
    z = zipper(0.8, 38, 72, 2100, 3600)
    buf = np.zeros(len(z) + int(SR * 0.15))
    add(buf, ring(2900, 0.01, 0.08, 0.5), 0.0)
    add(buf, z, 0.03)
    add(buf, ring(1900, 0.014, 0.12, 0.8) + ring(260, 0.03, 0.12, 0.5), 0.83)        # slider clacks home
    return buf

def make_insert():
    buf = np.zeros(int(SR * 1.0))
    # velcro rip: dense crackle
    n = int(SR * 0.34)
    spikes = (rng.random(n) < 0.035) * rng.uniform(0.3, 1.0, n)
    kern = np.exp(-np.arange(int(SR * 0.003)) / (SR * 0.0007))
    rasp = hp(np.convolve(spikes, kern)[:n], 900)
    rasp *= np.hanning(n) ** 0.4
    add(buf, rasp * 1.4, 0.0)
    # plate sliding against fabric
    n2 = int(SR * 0.3)
    slide = bp(noise(n2), 350, 1600) * np.hanning(n2) * 0.35
    add(buf, slide, 0.3)
    # seat: dull thud + small ceramic tick
    add(buf, sweep(130, 58, 0.22, 0.07, 1.0), 0.58)
    n3 = int(SR * 0.05)
    add(buf, lp(noise(n3), 1500) * np.exp(-np.linspace(0, 1, n3) * 7) * 0.7, 0.58)
    add(buf, ring(3400, 0.01, 0.06, 0.25), 0.59)
    return buf

def make_break():
    buf = np.zeros(int(SR * 1.1))
    n = int(SR * 0.04)
    add(buf, hp(noise(n), 1800) * np.exp(-np.linspace(0, 1, n) * 5) * 1.6, 0.0)           # crack
    n = int(SR * 0.28)
    add(buf, bp(noise(n), 700, 4800) * np.exp(-np.linspace(0, 1, n) * 6) * 1.0, 0.005)     # crunch
    add(buf, sweep(95, 42, 0.3, 0.1, 1.2), 0.0)                                            # impact thump
    for _ in range(46):                                                                    # ceramic shards tinkling
        at = 0.03 + (rng.random() ** 1.8) * 0.7
        c = ring(rng.uniform(1800, 7800), rng.uniform(0.006, 0.03), 0.12,
                 rng.uniform(0.12, 0.5) * (1.0 - at * 0.8))
        add(buf, c, at)
    for _ in range(14):                                                                    # low debris
        at = 0.05 + rng.random() * 0.5
        add(buf, ring(rng.uniform(300, 900), 0.012, 0.06, rng.uniform(0.1, 0.3)), at)
    return buf

def make_throw():
    n = int(SR * 0.42)
    t = np.linspace(0, 1, n)
    out = np.zeros(n)
    for (lo, hi, pk, amp) in [(450, 1100, 0.30, 0.9), (1100, 2600, 0.42, 0.8), (2600, 5200, 0.55, 0.45)]:
        env = np.exp(-((t - pk) ** 2) / (2 * 0.12 ** 2))
        out += bp(noise(n), lo, hi) * env * amp
    out += lp(noise(n), 300) * np.hanning(n) * 0.35
    return fade(out, 0.02, 0.08)

def make_stick():
    buf = np.zeros(int(SR * 1.0))
    add(buf, sweep(210, 85, 0.18, 0.05, 1.1), 0.0)                                         # thunk
    n = int(SR * 0.03)
    add(buf, lp(noise(n), 3200) * np.exp(-np.linspace(0, 1, n) * 6) * 0.8, 0.0)
    add(buf, ring(2650, 0.22, 0.9, 0.30) + ring(4280, 0.15, 0.9, 0.17) + ring(6900, 0.08, 0.9, 0.08), 0.004)   # blade ring
    t = T(0.9)
    add(buf, 0.14 * np.sin(2 * np.pi * (310 + 9 * np.sin(2 * np.pi * 28 * t)) * t) * np.exp(-t / 0.45), 0.01)  # twang
    return buf

def make_hit():
    buf = np.zeros(int(SR * 0.55))
    add(buf, sweep(160, 60, 0.25, 0.08, 1.0), 0.0)
    n = int(SR * 0.12)
    add(buf, lp(noise(n), 1300) * np.exp(-np.linspace(0, 1, n) * 5) * 0.7, 0.0)
    n = int(SR * 0.06)
    add(buf, bp(noise(n), 2400, 6500) * np.exp(-np.linspace(0, 1, n) * 6) * 0.35, 0.0)
    return buf

def export_ogg(samples, rel, peak=0.85):
    x = samples / (np.max(np.abs(samples)) + 1e-9) * peak
    data = (x * 32767).astype(np.int16)
    out = os.path.join(ROOT, rel)
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with tempfile.TemporaryDirectory() as td:
        wav = os.path.join(td, "s.wav")
        wavfile.write(wav, SR, data)
        r = subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-ac", "1",
                            "-c:a", "libvorbis", "-qscale:a", "5", out])
        if r.returncode != 0:
            r = subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-ac", "1",
                                "-c:a", "vorbis", "-strict", "-2", out])
        if r.returncode != 0:
            sys.exit("ffmpeg could not encode OGG for " + rel)


# =====================================================================
if __name__ == "__main__":
    p, knife_atlas = make_knife_texture();  print("wrote", p)
    p, plate_atlas = make_plate_texture();  print("wrote", p)

    kmodel = make_knife_model(); write_json("models/item/throwing_knife.json", kmodel)
    pmodel = make_plate_model(); write_json("models/item/armor_plate.json", pmodel)
    print("wrote models")

    prev_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "previews")
    os.makedirs(prev_dir, exist_ok=True)
    preview(kmodel, knife_atlas, os.path.join(prev_dir, "knife_front.png"))
    preview(pmodel, plate_atlas, os.path.join(prev_dir, "plate_front.png"))
    Image.fromarray(knife_atlas.astype(np.uint8), "RGBA").resize((512, 512), Image.NEAREST).save(os.path.join(prev_dir, "knife_atlas.png"))
    Image.fromarray(plate_atlas.astype(np.uint8), "RGBA").resize((512, 512), Image.NEAREST).save(os.path.join(prev_dir, "plate_atlas.png"))

    export_ogg(make_unzip(),  "sounds/plate/unzip.ogg")
    export_ogg(make_zip(),    "sounds/plate/zip.ogg")
    export_ogg(make_insert(), "sounds/plate/insert.ogg")
    export_ogg(make_break(),  "sounds/plate/break.ogg", 0.95)
    export_ogg(make_throw(),  "sounds/knife/throw.ogg")
    export_ogg(make_stick(),  "sounds/knife/stick.ogg")
    export_ogg(make_hit(),    "sounds/knife/hit.ogg")
    print("wrote sounds")
