package dev.mwextras;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, MWExtras.MODID);

    // plates
    public static final RegistryObject<SoundEvent> UNZIP  = reg("item.plate.unzip");
    public static final RegistryObject<SoundEvent> ZIP    = reg("item.plate.zip");
    public static final RegistryObject<SoundEvent> INSERT = reg("item.plate.insert");
    public static final RegistryObject<SoundEvent> PLATE_BREAK = reg("item.plate.break");
    // knife
    public static final RegistryObject<SoundEvent> KNIFE_THROW = reg("item.knife.throw");
    public static final RegistryObject<SoundEvent> KNIFE_STICK = reg("item.knife.stick");
    public static final RegistryObject<SoundEvent> KNIFE_HIT   = reg("item.knife.hit");
    // bomb
    public static final RegistryObject<SoundEvent> KEYPAD      = reg("item.bomb.keypad");
    public static final RegistryObject<SoundEvent> ARM         = reg("item.bomb.arm");
    public static final RegistryObject<SoundEvent> BOMB_BEEP   = reg("block.bomb.beep");
    public static final RegistryObject<SoundEvent> DEFUSE_TICK = reg("item.bomb.defuse_tick");
    public static final RegistryObject<SoundEvent> DEFUSE_DONE = reg("item.bomb.defuse_done");
    // scorestreaks
    public static final RegistryObject<SoundEvent> STREAK_READY = reg("streak.ready");
    public static final RegistryObject<SoundEvent> STREAK_USE   = reg("streak.use");
    // radio-style callouts (synthesized voice)
    public static final RegistryObject<SoundEvent> VOICE_READY    = reg("voice.streak_ready");
    public static final RegistryObject<SoundEvent> VOICE_UAV      = reg("voice.uav");
    public static final RegistryObject<SoundEvent> VOICE_PACKAGE  = reg("voice.care_package");
    public static final RegistryObject<SoundEvent> VOICE_CLUSTER  = reg("voice.cluster_strike");
    public static final RegistryObject<SoundEvent> VOICE_PLANTED  = reg("voice.bomb_planted");
    public static final RegistryObject<SoundEvent> VOICE_DEFUSED  = reg("voice.bomb_defused");

    private static RegistryObject<SoundEvent> reg(String name) {
        return SOUNDS.register(name, () ->
                SoundEvent.createVariableRangeEvent(new ResourceLocation(MWExtras.MODID, name)));
    }
}
