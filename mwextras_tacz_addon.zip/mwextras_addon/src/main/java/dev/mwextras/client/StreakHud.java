package dev.mwextras.client;

import dev.mwextras.Streak;
import dev.mwextras.StreakClientCache;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;

/** Right-side scorestreak panel + the big READY / ONLINE banners. */
public class StreakHud {
    private static String bannerText = "";
    private static String bannerSub = "";
    private static int bannerColor = 0xFFFFFF;
    private static float bannerStart = -1000.0F;

    public static void onPacket(int kills, int used, int event, int slot) {
        StreakClientCache.kills = kills;
        StreakClientCache.usedMask = used;
        if (event != 1 && event != 2) return;

        Minecraft mc = Minecraft.getInstance();
        Streak s = Streak.values()[Mth.clamp(slot, 0, Streak.values().length - 1)];
        bannerStart = mc.level != null ? mc.level.getGameTime() : 0;
        if (event == 1) {
            bannerText = s.displayName.toUpperCase() + " READY";
            bannerSub = "Press [" + Keys.SLOT[s.ordinal()].getTranslatedKeyMessage().getString()
                    + "] or right click the card";
            bannerColor = 0x55FF55;
        } else {
            bannerText = s.displayName.toUpperCase() + " ONLINE";
            bannerSub = "";
            bannerColor = 0xFFAA00;
        }
    }

    public static final IGuiOverlay OVERLAY = (gui, g, partialTick, width, height) -> {
        Minecraft mc = gui.getMinecraft();
        if (mc.player == null || mc.level == null || mc.options.hideGui) return;
        Font font = mc.font;
        float now = mc.level.getGameTime() + partialTick;

        // ---------------- slot panel ----------------
        int w = 118, h = 24, gap = 3;
        int x = width - w - 4;
        int y = height / 2 - (Streak.values().length * (h + gap)) / 2;
        int kills = StreakClientCache.kills;

        for (Streak s : Streak.values()) {
            boolean used = (StreakClientCache.usedMask & (1 << s.ordinal())) != 0;
            boolean ready = kills >= s.kills && !used;
            float pulse = 0.5F + 0.5F * Mth.sin(now * 0.3F);

            int accent = used ? 0xFF555555 : ready ? 0xFF55FF55 : 0xFFAA7A22;
            g.fill(x, y, x + w, y + h, ready ? 0xB0102A10 : 0x90000000);
            g.fill(x, y, x + 2, y + h, accent);
            if (ready) {   // pulsing outline
                int a = 0x40 + (int) (0x90 * pulse);
                int c = (a << 24) | 0x55FF55;
                g.fill(x, y, x + w, y + 1, c);
                g.fill(x, y + h - 1, x + w, y + h, c);
            }

            ItemStack icon = new ItemStack(s.item());
            g.renderItem(icon, x + 5, y + 4);

            String key = Keys.SLOT[s.ordinal()].getTranslatedKeyMessage().getString();
            g.drawString(font, s.displayName, x + 26, y + 3, used ? 0xFF777777 : 0xFFFFFFFF, true);
            String status = used ? "USED" : ready ? "READY [" + key + "]" : Math.min(kills, s.kills) + "/" + s.kills + " KILLS";
            g.drawString(font, status, x + 26, y + 13, used ? 0xFF777777 : ready ? 0xFF55FF55 : 0xFFCCCCCC, true);

            if (!used && !ready) {   // progress bar
                int bw = w - 4;
                int fill = (int) (bw * Math.min(1.0F, kills / (float) s.kills));
                g.fill(x + 2, y + h - 2, x + 2 + bw, y + h - 1, 0xFF222222);
                g.fill(x + 2, y + h - 2, x + 2 + fill, y + h - 1, 0xFFFFAA00);
            }
            y += h + gap;
        }

        // ---------------- banner ----------------
        float age = now - bannerStart;
        if (age >= 0.0F && age < 70.0F) {
            float in = Mth.clamp(age / 6.0F, 0.0F, 1.0F);
            float out = Mth.clamp((70.0F - age) / 15.0F, 0.0F, 1.0F);
            int alpha = Math.max(10, (int) (255 * Math.min(in, out)));
            float ease = 1.0F - (1.0F - in) * (1.0F - in);
            int by = (int) (Mth.lerp(ease, 10.0F, 48.0F));
            int color = (alpha << 24) | bannerColor;

            g.pose().pushPose();
            g.pose().translate(width / 2.0F, by, 0.0F);
            g.pose().scale(2.2F, 2.2F, 1.0F);
            g.drawCenteredString(font, bannerText, 0, 0, color);
            g.pose().popPose();
            if (!bannerSub.isEmpty()) {
                g.drawCenteredString(font, bannerSub, width / 2, by + 24, (alpha << 24) | 0xDDDDDD);
            }
        }
    };
}
