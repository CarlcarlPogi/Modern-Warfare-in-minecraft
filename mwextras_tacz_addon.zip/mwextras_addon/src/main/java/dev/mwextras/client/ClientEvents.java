package dev.mwextras.client;

import dev.mwextras.ActivateStreakPacket;
import dev.mwextras.MWExtras;
import dev.mwextras.ModItems;
import dev.mwextras.Net;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = MWExtras.MODID, value = Dist.CLIENT)
public class ClientEvents {

    /** Scorestreak keys -> server. */
    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        for (int i = 0; i < Keys.SLOT.length; i++) {
            while (Keys.SLOT[i].consumeClick()) {
                if (mc.player != null && mc.screen == null) {
                    Net.CHANNEL.sendToServer(new ActivateStreakPacket(i));
                }
            }
        }
    }

    /** Camera movement: head dips while applying plates / planting / defusing, small kick on a knife throw. */
    @SubscribeEvent
    public static void onCamera(ViewportEvent.ComputeCameraAngles event) {
        LocalPlayer p = Minecraft.getInstance().player;
        if (p == null) return;
        float pt = (float) event.getPartialTick();

        if (p.isUsingItem()) {
            ItemStack s = p.getUseItem();
            float dip = 0.0F, shake = 0.0F;
            if (s.is(ModItems.ARMOR_PLATE.get())) { dip = 6.0F; shake = 0.7F; }
            else if (s.is(ModItems.DEMOLITION_CHARGE.get())) { dip = 15.0F; shake = 0.25F; }
            else if (s.is(ModItems.DEFUSE_KIT.get())) { dip = 10.0F; shake = 0.5F; }

            if (dip > 0.0F) {
                float total = s.getUseDuration();
                float used = total - p.getUseItemRemainingTicks() + pt;
                float t = Mth.clamp(used / total, 0.0F, 1.0F);
                float k = smooth(t / 0.12F) * (1.0F - smooth((t - 0.9F) / 0.1F));
                event.setPitch(event.getPitch() + dip * k);
                event.setRoll(event.getRoll() + shake * k * Mth.sin(used * 0.9F));
            }
        }

        if (p.getMainHandItem().is(ModItems.THROWING_KNIFE.get())) {
            float a = p.getAttackAnim(pt);
            if (a > 0.0F) event.setPitch(event.getPitch() - 1.8F * Mth.sin(a * Mth.PI));
        }
    }

    private static float smooth(float x) {
        x = Mth.clamp(x, 0.0F, 1.0F);
        return x * x * (3.0F - 2.0F * x);
    }
}
