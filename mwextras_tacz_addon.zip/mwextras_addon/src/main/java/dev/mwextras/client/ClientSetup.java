package dev.mwextras.client;

import dev.mwextras.MWExtras;
import dev.mwextras.ModEntities;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = MWExtras.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.THROWN_KNIFE.get(), ThrownKnifeRenderer::new);
        event.registerEntityRenderer(ModEntities.PLANTED_BOMB.get(), PlantedBombRenderer::new);
    }

    @SubscribeEvent
    public static void registerOverlays(RegisterGuiOverlaysEvent event) {
        // Registered BELOW the health overlay so we can reserve a row and push the hearts up.
        event.registerBelow(VanillaGuiOverlay.PLAYER_HEALTH.id(), "plate_bar", PlateHud.OVERLAY);
        event.registerAboveAll("streaks", StreakHud.OVERLAY);
    }

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent event) {
        for (var key : Keys.SLOT) event.register(key);
    }
}
