package dev.mwextras.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;

import dev.mwextras.Config;
import dev.mwextras.ModItems;
import dev.mwextras.PlantedBomb;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

/** Draws the 3D bomb model, flashes it on every beep and prints a live countdown on its screen. */
public class PlantedBombRenderer extends EntityRenderer<PlantedBomb> {
    private final ItemStack stack = new ItemStack(ModItems.DEMOLITION_CHARGE.get());
    private final ItemRenderer itemRenderer;

    public PlantedBombRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.itemRenderer = ctx.getItemRenderer();
        this.shadowRadius = 0.3F;
    }

    @Override
    public void render(PlantedBomb bomb, float yaw, float partialTick, PoseStack pose,
                       MultiBufferSource buffers, int light) {
        int left = bomb.getTicksLeft();
        int fuse = Config.BOMB_FUSE.get();
        int interval = left > fuse * 2 / 3 ? 20 : left > fuse / 3 ? 12 : left > fuse / 6 ? 7 : left > 60 ? 4 : 2;
        boolean flash = (left % interval) < 3 || bomb.isDefusing();
        int lt = flash ? LightTexture.FULL_BRIGHT : light;

        pose.pushPose();
        pose.mulPose(Axis.YP.rotationDegrees(-Mth.lerp(partialTick, bomb.yRotO, bomb.getYRot())));
        pose.translate(0.0F, 0.25F, 0.0F);

        pose.pushPose();
        pose.scale(1.3F, 1.3F, 1.3F);
        itemRenderer.renderStatic(stack, ItemDisplayContext.FIXED, lt, OverlayTexture.NO_OVERLAY,
                pose, buffers, bomb.level(), bomb.getId());
        pose.popPose();

        // countdown on the front screen
        int secs = (left + 19) / 20;
        String text = String.format("%d:%02d", secs / 60, secs % 60);
        Font font = this.getFont();
        pose.pushPose();
        pose.translate(-0.146F, 0.18F, 0.272F);
        pose.scale(0.012F, -0.012F, 0.012F);
        font.drawInBatch(text, -font.width(text) / 2.0F, -4.0F, 0xFFFF3030, false,
                pose.last().pose(), buffers, Font.DisplayMode.NORMAL, 0, LightTexture.FULL_BRIGHT);
        pose.popPose();

        pose.popPose();
        super.render(bomb, yaw, partialTick, pose, buffers, light);
    }

    @Override
    public ResourceLocation getTextureLocation(PlantedBomb bomb) {
        return TextureAtlas.LOCATION_BLOCKS;
    }
}
