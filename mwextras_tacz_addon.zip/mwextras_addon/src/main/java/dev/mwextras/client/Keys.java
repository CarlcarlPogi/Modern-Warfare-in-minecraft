package dev.mwextras.client;

import com.mojang.blaze3d.platform.InputConstants;

import net.minecraft.client.KeyMapping;

/** One key per scorestreak slot. Rebindable in Options > Controls > MW Extras. */
public class Keys {
    public static final String CATEGORY = "key.categories.mwextras";
    public static final KeyMapping[] SLOT = {
            new KeyMapping("key.mwextras.streak1", InputConstants.KEY_Z, CATEGORY),
            new KeyMapping("key.mwextras.streak2", InputConstants.KEY_X, CATEGORY),
            new KeyMapping("key.mwextras.streak3", InputConstants.KEY_C, CATEGORY),
    };
}
