package dev.mwextras;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MWExtras.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MWExtras.MODID);

    public static final RegistryObject<Item> THROWING_KNIFE = ITEMS.register("throwing_knife",
            () -> new ThrowingKnifeItem(new Item.Properties().stacksTo(8)));
    public static final RegistryObject<Item> ARMOR_PLATE = ITEMS.register("armor_plate",
            () -> new ArmorPlateItem(new Item.Properties().stacksTo(5)));

    // Search & Destroy
    public static final RegistryObject<Item> DEMOLITION_CHARGE = ITEMS.register("demolition_charge",
            () -> new DemolitionChargeItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> DEFUSE_KIT = ITEMS.register("defuse_kit",
            () -> new DefuseKitItem(new Item.Properties().stacksTo(1)));

    // Scorestreak cards (given when a streak unlocks)
    public static final RegistryObject<Item> STREAK_UAV = ITEMS.register("streak_uav",
            () -> new StreakCardItem(new Item.Properties().stacksTo(1), Streak.UAV));
    public static final RegistryObject<Item> STREAK_CARE_PACKAGE = ITEMS.register("streak_care_package",
            () -> new StreakCardItem(new Item.Properties().stacksTo(1), Streak.CARE_PACKAGE));
    public static final RegistryObject<Item> STREAK_CLUSTER = ITEMS.register("streak_cluster_strike",
            () -> new StreakCardItem(new Item.Properties().stacksTo(1), Streak.CLUSTER_STRIKE));

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.mwextras"))
                    .icon(() -> new ItemStack(ARMOR_PLATE.get()))
                    .displayItems((params, out) -> {
                        out.accept(THROWING_KNIFE.get());
                        out.accept(ARMOR_PLATE.get());
                        out.accept(DEMOLITION_CHARGE.get());
                        out.accept(DEFUSE_KIT.get());
                        out.accept(STREAK_UAV.get());
                        out.accept(STREAK_CARE_PACKAGE.get());
                        out.accept(STREAK_CLUSTER.get());
                    })
                    .build());
}
