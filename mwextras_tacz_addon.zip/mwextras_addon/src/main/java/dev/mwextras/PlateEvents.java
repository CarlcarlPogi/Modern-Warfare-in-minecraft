package dev.mwextras;

import net.minecraft.core.particles.ItemParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.registries.ForgeRegistries;

@Mod.EventBusSubscriber(modid = MWExtras.MODID)
public class PlateEvents {

    /** Fires before vanilla armor reduction, so plates soak raw bullet damage. */
    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onHurt(LivingHurtEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;

        int plates = PlateData.get(player);
        if (plates <= 0 || !isBullet(event.getSource())) return;

        float soaked = (float) Math.min(event.getAmount(), Config.PLATE_ABSORB.get());
        event.setAmount(event.getAmount() - soaked);

        int remaining = plates - 1;
        PlateData.set(player, remaining);

        ServerLevel level = player.serverLevel();
        level.playSound(null, player.getX(), player.getY() + 1.1, player.getZ(),
                ModSounds.PLATE_BREAK.get(), SoundSource.PLAYERS,
                1.0F, 0.92F + level.random.nextFloat() * 0.16F);
        level.sendParticles(
                new ItemParticleOption(ParticleTypes.ITEM, new ItemStack(ModItems.ARMOR_PLATE.get())),
                player.getX(), player.getY() + 1.2, player.getZ(),
                16, 0.25, 0.3, 0.25, 0.09);

        // HUD: remaining plates + which slot to shatter (always the right-most filled one)
        Net.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new PlatePacket(remaining, remaining));
    }

    /** TaCZ bullets: detected by entity namespace, damage type namespace, or a "bullet" message id. */
    static boolean isBullet(DamageSource src) {
        Entity direct = src.getDirectEntity();
        if (direct != null) {
            ResourceLocation id = ForgeRegistries.ENTITY_TYPES.getKey(direct.getType());
            if (id != null && id.getNamespace().equals("tacz")) return true;
        }
        var key = src.typeHolder().unwrapKey();
        if (key.isPresent() && key.get().location().getNamespace().equals("tacz")) return true;
        if (src.getMsgId() != null && src.getMsgId().toLowerCase().contains("bullet")) return true;
        return Config.ANY_PROJECTILE.get() && src.is(DamageTypeTags.IS_PROJECTILE);
    }

    // ---- keep the client in sync / lose plates on death ----
    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        if (!(event.getEntity() instanceof ServerPlayer np)) return;
        PlateData.set(np, event.isWasDeath() ? 0 : event.getOriginal().getPersistentData().getInt("mwextras_plates"));
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) PlateData.sync(sp);
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) PlateData.sync(sp);
    }

    @SubscribeEvent
    public static void onDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) PlateData.sync(sp);
    }
}
