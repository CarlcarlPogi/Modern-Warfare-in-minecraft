package dev.mwextras;

import java.util.function.Supplier;

import dev.mwextras.client.StreakHud;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

public record StreakPacket(int kills, int used, int event, int slot) {
    public static void encode(StreakPacket m, FriendlyByteBuf b) {
        b.writeVarInt(m.kills); b.writeVarInt(m.used); b.writeVarInt(m.event); b.writeVarInt(m.slot);
    }
    public static StreakPacket decode(FriendlyByteBuf b) {
        return new StreakPacket(b.readVarInt(), b.readVarInt(), b.readVarInt(), b.readVarInt());
    }
    public static void handle(StreakPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> StreakHud.onPacket(m.kills, m.used, m.event, m.slot)));
        ctx.get().setPacketHandled(true);
    }
}
