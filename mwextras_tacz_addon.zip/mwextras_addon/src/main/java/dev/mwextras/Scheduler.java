package dev.mwextras;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

/** Tiny "run this in N ticks" helper for the server thread. */
@Mod.EventBusSubscriber(modid = MWExtras.MODID)
public class Scheduler {
    private record Task(long runAt, Runnable run) {}
    private static final List<Task> TASKS = new ArrayList<>();

    public static void later(int ticks, Runnable run) {
        var server = ServerLifecycleHooks.getCurrentServer();
        if (server == null) return;
        TASKS.add(new Task(server.getTickCount() + ticks, run));
    }

    @SubscribeEvent
    public static void tick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || TASKS.isEmpty()) return;
        var server = ServerLifecycleHooks.getCurrentServer();
        if (server == null) return;
        long now = server.getTickCount();
        List<Runnable> due = new ArrayList<>();
        for (Iterator<Task> it = TASKS.iterator(); it.hasNext();) {
            Task t = it.next();
            if (t.runAt() <= now) { due.add(t.run()); it.remove(); }
        }
        for (Runnable r : due) {
            try { r.run(); } catch (Exception ex) { ex.printStackTrace(); }
        }
    }
}
