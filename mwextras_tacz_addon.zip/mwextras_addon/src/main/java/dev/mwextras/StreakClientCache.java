package dev.mwextras;

/** Client-side copy of the local player's streak progress. Plain holder, safe on servers. */
public class StreakClientCache {
    public static int kills = 0;
    public static int usedMask = 0;
}
