package dev.mwextras;

import java.util.function.Consumer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;

import net.minecraft.client.player.LocalPlayer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stats;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;

public class ThrowingKnifeItem extends Item {
    /** Ticks between pressing the button and the knife leaving the hand (matches the wind-up animation). */
    private static final int RELEASE_DELAY = 3;

    public ThrowingKnifeItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        boolean creative = player.getAbilities().instabuild;

        if (!level.isClientSide && player instanceof ServerPlayer sp) {
            Scheduler.later(RELEASE_DELAY, () -> {
                if (!sp.isAlive()) return;
                level.playSound(null, sp.getX(), sp.getEyeY(), sp.getZ(), ModSounds.KNIFE_THROW.get(),
                        SoundSource.PLAYERS, 0.9F, 0.92F + level.getRandom().nextFloat() * 0.16F);
                ThrownKnife knife = new ThrownKnife(level, sp);
                knife.shootFromRotation(sp, sp.getXRot(), sp.getYRot(), 0.0F,
                        Config.KNIFE_SPEED.get().floatValue(), 0.35F);
                if (creative) knife.pickup = AbstractArrow.Pickup.CREATIVE_ONLY;
                level.addFreshEntity(knife);
            });
        }

        player.awardStat(Stats.ITEM_USED.get(this));
        if (!creative) stack.shrink(1);
        player.getCooldowns().addCooldown(this, Config.KNIFE_COOLDOWN.get());
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    // ------------------------------------------------------------------
    // First person: flip-up draw animation + wind-up / fling throw animation
    // ------------------------------------------------------------------
    @Override
    public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(new IClientItemExtensions() {
            @Override
            public boolean applyForgeHandTransform(PoseStack pose, LocalPlayer player, HumanoidArm arm,
                                                   ItemStack stack, float partialTick, float equip, float swing) {
                int side = arm == HumanoidArm.RIGHT ? 1 : -1;
                pose.translate(side * 0.56F, -0.52F + equip * -0.6F, -0.72F);

                // DRAW: knife flips up out of the lowered position with a little twist
                if (equip > 0.0F) {
                    float e = equip * equip;
                    pose.mulPose(Axis.XP.rotationDegrees(-115.0F * e));
                    pose.mulPose(Axis.ZP.rotationDegrees(side * 35.0F * e));
                    pose.mulPose(Axis.YP.rotationDegrees(side * -25.0F * e));
                }

                // THROW: pull back and up (0 -> 0.4), then snap forward and settle (0.4 -> 1)
                if (swing > 0.0F) {
                    if (swing < 0.4F) {
                        float u = easeOut(swing / 0.4F);
                        pose.translate(side * 0.04F * u, 0.10F * u, 0.26F * u);
                        pose.mulPose(Axis.XP.rotationDegrees(-34.0F * u));
                        pose.mulPose(Axis.ZP.rotationDegrees(side * -10.0F * u));
                    } else {
                        float u = (swing - 0.4F) / 0.6F;
                        float f = easeOut(Math.min(u * 2.2F, 1.0F));
                        float settle = 1.0F - u;
                        pose.translate(0.0F, (0.10F * (1.0F - f) - 0.06F * f * settle),
                                0.26F * (1.0F - f) - 0.38F * f * settle);
                        pose.mulPose(Axis.XP.rotationDegrees(-34.0F * (1.0F - f) + 58.0F * f * settle));
                    }
                }
                return true;
            }

            private float easeOut(float x) {
                x = Mth.clamp(x, 0.0F, 1.0F);
                return 1.0F - (1.0F - x) * (1.0F - x) * (1.0F - x);
            }
        });
    }
}
