package dev.mwextras;

import java.util.function.Supplier;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

/** Client -> server: the player pressed streak key `slot`. */
public record ActivateStreakPacket(int slot) {
    public static void encode(ActivateStreakPacket m, FriendlyByteBuf b) { b.writeVarInt(m.slot); }
    public static ActivateStreakPacket decode(FriendlyByteBuf b) { return new ActivateStreakPacket(b.readVarInt()); }
    public static void handle(ActivateStreakPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sp = ctx.get().getSender();
            if (sp != null) StreakActions.activateSlot(sp, m.slot);
        });
        ctx.get().setPacketHandled(true);
    }
}
