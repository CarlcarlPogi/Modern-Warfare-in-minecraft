package dev.mwextras;

import java.util.List;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import javax.annotation.Nullable;

/** The item you are given when a streak unlocks. Right click (or press its key) to call it in. */
public class StreakCardItem extends Item {
    private final Streak streak;

    public StreakCardItem(Properties props, Streak streak) {
        super(props);
        this.streak = streak;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && player instanceof ServerPlayer sp) {
            StreakActions.activate(sp, streak, stack);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tips, TooltipFlag flag) {
        tips.add(Component.literal("Scorestreak - " + streak.kills + " kills").withStyle(net.minecraft.ChatFormatting.GOLD));
        tips.add(Component.literal("Right click or press its key").withStyle(net.minecraft.ChatFormatting.GRAY));
    }
}
