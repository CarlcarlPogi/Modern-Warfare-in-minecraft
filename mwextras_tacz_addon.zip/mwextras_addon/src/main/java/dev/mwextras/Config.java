package dev.mwextras;

import net.minecraftforge.common.ForgeConfigSpec;

public class Config {
    private static final ForgeConfigSpec.Builder B = new ForgeConfigSpec.Builder();

    // ---- plates ----
    public static final ForgeConfigSpec.IntValue MAX_PLATES = B
            .comment("How many plate slots the HUD bar has / how many plates a player can wear.")
            .defineInRange("maxPlates", 3, 1, 6);
    public static final ForgeConfigSpec.DoubleValue PLATE_ABSORB = B
            .comment("Max damage ONE plate soaks from a single hit before it is destroyed.",
                     "Anything above this goes through. Set very high (1000) for 'a plate eats the whole shot'.")
            .defineInRange("plateAbsorb", 12.0, 0.0, 1000.0);
    public static final ForgeConfigSpec.IntValue PLATE_USE_TICKS = B
            .comment("How long applying one plate takes, in ticks (20 = 1 second).")
            .defineInRange("plateUseTicks", 50, 10, 200);
    public static final ForgeConfigSpec.BooleanValue ANY_PROJECTILE = B
            .comment("Also let plates break from vanilla/other-mod projectiles. TaCZ bullets always count.")
            .define("absorbAnyProjectile", false);

    // ---- knife ----
    public static final ForgeConfigSpec.DoubleValue KNIFE_DAMAGE = B
            .comment("Damage of a thrown knife (2 = 1 heart).")
            .defineInRange("knifeDamage", 14.0, 1.0, 100.0);
    public static final ForgeConfigSpec.DoubleValue KNIFE_HEAD_MULT = B
            .defineInRange("knifeHeadshotMultiplier", 1.5, 1.0, 10.0);
    public static final ForgeConfigSpec.DoubleValue KNIFE_SPEED = B
            .defineInRange("knifeSpeed", 2.8, 0.5, 6.0);
    public static final ForgeConfigSpec.IntValue KNIFE_COOLDOWN = B
            .defineInRange("knifeCooldownTicks", 12, 0, 100);

    // ---- search & destroy bomb ----
    public static final ForgeConfigSpec.IntValue BOMB_FUSE = B
            .comment("Ticks until a planted bomb explodes (1200 = 60 seconds).")
            .defineInRange("bombFuseTicks", 1200, 100, 12000);
    public static final ForgeConfigSpec.IntValue BOMB_PLANT_TICKS = B
            .comment("Ticks to plant the bomb (64 = 3.2 seconds).")
            .defineInRange("bombPlantTicks", 64, 20, 400);
    public static final ForgeConfigSpec.IntValue BOMB_DEFUSE_TICKS = B
            .comment("Ticks to defuse the bomb (100 = 5 seconds).")
            .defineInRange("bombDefuseTicks", 100, 20, 400);
    public static final ForgeConfigSpec.DoubleValue BOMB_POWER = B
            .comment("Explosion radius (TNT = 4).")
            .defineInRange("bombExplosionPower", 7.0, 1.0, 30.0);
    public static final ForgeConfigSpec.BooleanValue BOMB_BLOCK_DAMAGE = B
            .comment("Whether the bomb explosion destroys blocks.")
            .define("bombDestroysBlocks", true);

    // ---- scorestreaks ----
    public static final ForgeConfigSpec.BooleanValue STREAK_COUNT_MOBS = B
            .comment("Kills of hostile mobs count toward the streak (players always count).")
            .define("streakCountMobs", true);
    public static final ForgeConfigSpec.IntValue UAV_RANGE = B
            .defineInRange("uavRange", 96, 16, 512);
    public static final ForgeConfigSpec.IntValue UAV_SECONDS = B
            .defineInRange("uavSeconds", 20, 5, 120);
    public static final ForgeConfigSpec.BooleanValue STREAK_BLOCK_DAMAGE = B
            .comment("Whether Cluster Strike explosions destroy blocks.")
            .define("clusterStrikeDestroysBlocks", false);

    public static final ForgeConfigSpec SPEC = B.build();
}
