package dev.mwextras;

import java.util.function.Supplier;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.item.Item;

/** The three scorestreaks. Slot index = ordinal = key bind index. */
public enum Streak {
    UAV("UAV", 3,
            () -> ModItems.STREAK_UAV.get(), () -> ModSounds.VOICE_UAV.get()),
    CARE_PACKAGE("Care Package", 5,
            () -> ModItems.STREAK_CARE_PACKAGE.get(), () -> ModSounds.VOICE_PACKAGE.get()),
    CLUSTER_STRIKE("Cluster Strike", 7,
            () -> ModItems.STREAK_CLUSTER.get(), () -> ModSounds.VOICE_CLUSTER.get());

    public final String displayName;
    public final int kills;
    private final Supplier<Item> item;
    private final Supplier<SoundEvent> voice;

    Streak(String displayName, int kills, Supplier<Item> item, Supplier<SoundEvent> voice) {
        this.displayName = displayName;
        this.kills = kills;
        this.item = item;
        this.voice = voice;
    }

    public Item item() { return item.get(); }
    public SoundEvent voice() { return voice.get(); }
}
