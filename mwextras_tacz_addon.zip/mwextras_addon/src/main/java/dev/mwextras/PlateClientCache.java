package dev.mwextras;

/** Client-side copy of the local player's plate count. Plain holder: safe to load on a server. */
public class PlateClientCache {
    public static int plates = 0;
}
