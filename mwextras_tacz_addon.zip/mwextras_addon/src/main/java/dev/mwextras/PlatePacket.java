package dev.mwextras;

import java.util.function.Supplier;

import dev.mwextras.client.PlateHud;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/** plates = new plate count. broken = slot index that just shattered, or -1 for a silent sync. */
public record PlatePacket(int plates, int broken) {

    public static void encode(PlatePacket m, FriendlyByteBuf buf) {
        buf.writeVarInt(m.plates);
        buf.writeVarInt(m.broken + 1);
    }

    public static PlatePacket decode(FriendlyByteBuf buf) {
        return new PlatePacket(buf.readVarInt(), buf.readVarInt() - 1);
    }

    public static void handle(PlatePacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> PlateHud.onPacket(m.plates, m.broken)));
        ctx.get().setPacketHandled(true);
    }
}
