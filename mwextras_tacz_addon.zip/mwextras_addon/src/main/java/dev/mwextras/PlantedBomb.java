package dev.mwextras;

import java.util.UUID;

import javax.annotation.Nullable;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.NetworkHooks;

/** The planted Search & Destroy bomb: beeps faster as it runs down, explodes at 0, can be defused. */
public class PlantedBomb extends Entity {
    private static final EntityDataAccessor<Integer> TICKS =
            SynchedEntityData.defineId(PlantedBomb.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> DEFUSING =
            SynchedEntityData.defineId(PlantedBomb.class, EntityDataSerializers.BOOLEAN);

    @Nullable private UUID owner;

    public PlantedBomb(EntityType<? extends PlantedBomb> type, Level level) {
        super(type, level);
        this.noPhysics = true;
    }

    public PlantedBomb(Level level, double x, double y, double z, @Nullable Player owner, float yaw) {
        this(ModEntities.PLANTED_BOMB.get(), level);
        this.setPos(x, y, z);
        this.setYRot(yaw);
        this.yRotO = yaw;
        if (owner != null) this.owner = owner.getUUID();
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(TICKS, Config.BOMB_FUSE.get());
        this.entityData.define(DEFUSING, false);
    }

    public int getTicksLeft() { return this.entityData.get(TICKS); }
    public boolean isDefusing() { return this.entityData.get(DEFUSING); }
    public void setDefusing(boolean b) { this.entityData.set(DEFUSING, b); }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) return;

        int left = getTicksLeft() - 1;
        this.entityData.set(TICKS, left);

        int fuse = Config.BOMB_FUSE.get();
        int interval = left > fuse * 2 / 3 ? 20 : left > fuse / 3 ? 12 : left > fuse / 6 ? 7 : left > 60 ? 4 : 2;
        if (left % interval == 0) {
            float urgency = 1.0F - (float) left / fuse;
            this.level().playSound(null, getX(), getY(), getZ(), ModSounds.BOMB_BEEP.get(),
                    SoundSource.BLOCKS, 2.0F, 0.9F + urgency * 0.6F);
        }

        if (left <= 0) {
            Level.ExplosionInteraction mode = Config.BOMB_BLOCK_DAMAGE.get()
                    ? Level.ExplosionInteraction.TNT : Level.ExplosionInteraction.NONE;
            Entity cause = this;
            if (owner != null && this.level() instanceof net.minecraft.server.level.ServerLevel sl) {
                Entity o = sl.getEntity(owner);
                if (o != null) cause = o;
            }
            this.level().explode(cause, getX(), getY() + 0.2, getZ(),
                    Config.BOMB_POWER.get().floatValue(), mode);
            var server = this.level().getServer();
            if (server != null) {
                server.getPlayerList().broadcastSystemMessage(Component.literal("\u00a7cThe bomb has detonated!"), false);
            }
            this.discard();
        }
    }

    @Override public boolean isPickable() { return false; }
    @Override public boolean isPushable() { return false; }
    @Override public boolean isNoGravity() { return true; }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        this.entityData.set(TICKS, tag.getInt("Ticks"));
        if (tag.hasUUID("Owner")) this.owner = tag.getUUID("Owner");
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putInt("Ticks", getTicksLeft());
        if (owner != null) tag.putUUID("Owner", owner);
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
