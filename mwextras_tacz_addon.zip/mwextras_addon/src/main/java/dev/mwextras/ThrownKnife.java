package dev.mwextras;

import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraftforge.network.NetworkHooks;

/**
 * Arrow-based so it gets sticking-into-blocks, pickup and despawn behaviour for free.
 * It overrides the entity hit so damage is flat (not speed-scaled) with a headshot bonus.
 */
public class ThrownKnife extends AbstractArrow {

    public ThrownKnife(EntityType<? extends ThrownKnife> type, Level level) {
        super(type, level);
    }

    public ThrownKnife(Level level, LivingEntity owner) {
        super(ModEntities.THROWN_KNIFE.get(), owner, level);
    }

    @Override
    protected ItemStack getPickupItem() {
        return new ItemStack(ModItems.THROWING_KNIFE.get());
    }

    @Override
    protected SoundEvent getDefaultHitGroundSoundEvent() {
        return ModSounds.KNIFE_STICK.get();
    }

    /** Used by the renderer: stuck knives stop spinning. */
    public boolean isStuck() {
        return this.inGround;
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        Entity target = result.getEntity();
        Entity owner = this.getOwner();

        float damage = Config.KNIFE_DAMAGE.get().floatValue();
        if (target instanceof LivingEntity living
                && result.getLocation().y >= living.getEyeY() - 0.2D) {
            damage *= Config.KNIFE_HEAD_MULT.get().floatValue();
        }

        DamageSource source = this.damageSources().thrown(this, owner == null ? this : owner);
        if (target.hurt(source, damage)) {
            this.playSound(ModSounds.KNIFE_HIT.get(), 1.0F, 0.95F + this.random.nextFloat() * 0.1F);
            if (!this.level().isClientSide) {
                if (this.pickup == AbstractArrow.Pickup.ALLOWED) {
                    this.spawnAtLocation(this.getPickupItem(), 0.1F); // knife drops at the victim's feet
                }
                this.discard();
            }
        } else {
            // blocked / invulnerable: bounce off
            this.setDeltaMovement(this.getDeltaMovement().scale(-0.1D));
            this.setYRot(this.getYRot() + 180.0F);
            this.yRotO += 180.0F;
        }
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
