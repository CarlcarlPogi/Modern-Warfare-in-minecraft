package dev.mwextras;

import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public class Net {
    private static final String VERSION = "2";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(MWExtras.MODID, "main"),
            () -> VERSION, VERSION::equals, VERSION::equals);

    public static void register() {
        CHANNEL.registerMessage(0, PlatePacket.class,
                PlatePacket::encode, PlatePacket::decode, PlatePacket::handle);
        CHANNEL.registerMessage(1, StreakPacket.class,
                StreakPacket::encode, StreakPacket::decode, StreakPacket::handle);
        CHANNEL.registerMessage(2, ActivateStreakPacket.class,
                ActivateStreakPacket::encode, ActivateStreakPacket::decode, ActivateStreakPacket::handle);
    }
}
