package dev.mwextras;

import java.util.Comparator;
import java.util.function.Consumer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;

import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;

/** Hold right click next to a planted bomb to cut the wires. */
public class DefuseKitItem extends Item {
    private static final double RANGE = 3.2D;

    public DefuseKitItem(Properties props) {
        super(props);
    }

    @Override public int getUseDuration(ItemStack stack) { return Config.BOMB_DEFUSE_TICKS.get(); }
    @Override public UseAnim getUseAnimation(ItemStack stack) { return UseAnim.CUSTOM; }

    private static PlantedBomb findBomb(Level level, Player player) {
        return level.getEntitiesOfClass(PlantedBomb.class, player.getBoundingBox().inflate(RANGE))
                .stream().min(Comparator.comparingDouble(b -> b.distanceToSqr(player))).orElse(null);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        PlantedBomb bomb = findBomb(level, player);
        if (bomb == null) {
            if (!level.isClientSide) player.displayClientMessage(Component.literal("No bomb in range"), true);
            return InteractionResultHolder.fail(stack);
        }
        player.startUsingItem(hand);
        if (!level.isClientSide) bomb.setDefusing(true);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public void onUseTick(Level level, LivingEntity entity, ItemStack stack, int remaining) {
        if (level.isClientSide || !(entity instanceof Player player)) return;
        entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 4, 6, false, false, false));

        PlantedBomb bomb = findBomb(level, player);
        if (bomb == null) {                       // walked / was pushed away
            entity.stopUsingItem();
            return;
        }
        int used = getUseDuration(stack) - remaining;
        if (used % 10 == 5) {                     // wire clicks
            level.playSound(null, bomb.getX(), bomb.getY(), bomb.getZ(), ModSounds.DEFUSE_TICK.get(),
                    SoundSource.PLAYERS, 1.0F, 0.9F + level.random.nextFloat() * 0.2F);
        }
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        if (!level.isClientSide && entity instanceof ServerPlayer sp) {
            PlantedBomb bomb = findBomb(level, sp);
            if (bomb != null) {
                level.playSound(null, bomb.getX(), bomb.getY(), bomb.getZ(), ModSounds.DEFUSE_DONE.get(),
                        SoundSource.PLAYERS, 1.6F, 1.0F);
                bomb.discard();
                Announcer.toAll(sp.server, ModSounds.VOICE_DEFUSED.get(),
                        Component.literal("\u00a7aBOMB DEFUSED"),
                        Component.literal("\u00a77" + sp.getName().getString() + " cut the wire"));
            }
        }
        return stack;
    }

    @Override
    public void releaseUsing(ItemStack stack, Level level, LivingEntity entity, int timeLeft) {
        if (!level.isClientSide && entity instanceof Player player) {
            PlantedBomb bomb = findBomb(level, player);
            if (bomb != null) bomb.setDefusing(false);
        }
    }

    // ------------------------------------------------------------------
    // Defuse animation: cutters come up in front of the bomb, snip repeatedly, big final snip.
    // ------------------------------------------------------------------
    @Override
    public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(new IClientItemExtensions() {
            @Override
            public boolean applyForgeHandTransform(PoseStack pose, LocalPlayer player, HumanoidArm arm,
                                                   ItemStack stack, float pt, float equip, float swing) {
                int side = arm == HumanoidArm.RIGHT ? 1 : -1;
                pose.translate(side * 0.56F, -0.52F + equip * -0.6F, -0.72F);
                if (!player.isUsingItem() || player.getUseItem() != stack) return true;

                float total = Config.BOMB_DEFUSE_TICKS.get();
                float used = total - player.getUseItemRemainingTicks() + pt;
                float t = Mth.clamp(used / total, 0.0F, 1.0F);

                float bring = smooth(t / 0.12F) * (1.0F - smooth((t - 0.93F) / 0.07F));
                float working = (t > 0.12F && t < 0.92F) ? 1.0F : 0.0F;
                float wiggle = Mth.sin(used * 1.9F) * working * bring;
                float snip = Math.max(0.0F, 1.0F - Math.abs(used - 10.0F * (float) Math.floor(used / 10.0F) - 5.0F) / 1.4F) * working;
                float finale = Math.max(0.0F, 1.0F - Math.abs(t - 0.95F) / 0.04F);

                pose.translate(-side * 0.48F * bring + 0.012F * wiggle,
                        -0.06F * bring - 0.02F * snip, 0.14F * bring);
                pose.mulPose(Axis.XP.rotationDegrees(-22.0F * bring + 8.0F * snip - 20.0F * finale));
                pose.mulPose(Axis.ZP.rotationDegrees(side * 6.0F * wiggle));
                pose.mulPose(Axis.YP.rotationDegrees(side * 12.0F * bring));
                return true;
            }

            private float smooth(float x) {
                x = Mth.clamp(x, 0.0F, 1.0F);
                return x * x * (3.0F - 2.0F * x);
            }
        });
    }
}
