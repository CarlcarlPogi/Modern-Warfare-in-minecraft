package dev.mwextras;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = MWExtras.MODID)
public class StreakEvents {

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        LivingEntity victim = event.getEntity();

        // dying resets your streak
        if (victim instanceof ServerPlayer sp) {
            StreakData.set(sp, 0, 0);
            StreakData.sync(sp, 0, 0);
        }

        Entity src = event.getSource().getEntity();
        if (src instanceof ServerPlayer killer && killer != victim
                && (victim instanceof Player || (Config.STREAK_COUNT_MOBS.get() && victim instanceof Enemy))) {
            addKill(killer);
        }
    }

    private static void addKill(ServerPlayer killer) {
        int before = StreakData.kills(killer);
        int now = before + 1;
        StreakData.set(killer, now, StreakData.used(killer));

        int unlockedSlot = -1;
        for (Streak s : Streak.values()) {
            if (before < s.kills && now >= s.kills) {
                ItemStack card = new ItemStack(s.item());
                if (!killer.getInventory().add(card)) killer.drop(card, false);
                unlockedSlot = s.ordinal();
                killer.playNotifySound(ModSounds.STREAK_READY.get(), SoundSource.PLAYERS, 1.0F, 1.0F);
                killer.playNotifySound(ModSounds.VOICE_READY.get(), SoundSource.PLAYERS, 0.9F, 1.0F);
            }
        }
        StreakData.sync(killer, unlockedSlot >= 0 ? 1 : 0, Math.max(unlockedSlot, 0));
    }

    /** Streak cards vanish on death instead of dropping. */
    @SubscribeEvent
    public static void onDrops(LivingDropsEvent event) {
        if (event.getEntity() instanceof ServerPlayer) {
            event.getDrops().removeIf(e -> e.getItem().getItem() instanceof StreakCardItem);
        }
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone event) {
        if (!(event.getEntity() instanceof ServerPlayer np)) return;
        if (event.isWasDeath()) {
            StreakData.set(np, 0, 0);
        } else {
            var old = event.getOriginal().getPersistentData();
            StreakData.set(np, old.getInt("mwextras_kills"), old.getInt("mwextras_used"));
        }
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) StreakData.sync(sp, 0, 0);
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) StreakData.sync(sp, 0, 0);
    }

    @SubscribeEvent
    public static void onDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) StreakData.sync(sp, 0, 0);
    }
}
