package dev.mwextras;

import java.util.function.Consumer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;

import net.minecraft.client.player.LocalPlayer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;

/**
 * Warzone-style plate: hold right click -> vest unzips -> plate slides in -> vest zips -> +1 plate.
 */
public class ArmorPlateItem extends Item {

    public ArmorPlateItem(Properties props) {
        super(props);
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return Config.PLATE_USE_TICKS.get();
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.CUSTOM; // we animate it ourselves in applyForgeHandTransform
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (PlateData.get(player) >= Config.MAX_PLATES.get()) {
            return InteractionResultHolder.fail(stack);
        }
        player.startUsingItem(hand);
        if (!level.isClientSide) {
            level.playSound(null, player.getX(), player.getY() + 1.0, player.getZ(),
                    ModSounds.UNZIP.get(), SoundSource.PLAYERS, 0.9F, 1.0F);
        }
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public void onUseTick(Level level, LivingEntity entity, ItemStack stack, int remaining) {
        if (level.isClientSide) return;
        int total = getUseDuration(stack);
        int used = total - remaining;
        if (used == (int) (total * 0.38F)) { // plate slides in
            level.playSound(null, entity.getX(), entity.getY() + 1.0, entity.getZ(),
                    ModSounds.INSERT.get(), SoundSource.PLAYERS, 0.9F, 1.0F);
        }
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        if (entity instanceof Player player) {
            boolean creative = player.getAbilities().instabuild;
            if (!level.isClientSide && player instanceof ServerPlayer sp) {
                int now = PlateData.get(sp);
                if (now < Config.MAX_PLATES.get()) {
                    PlateData.set(sp, now + 1);
                    PlateData.sync(sp);
                    level.playSound(null, sp.getX(), sp.getY() + 1.0, sp.getZ(),
                            ModSounds.ZIP.get(), SoundSource.PLAYERS, 0.9F, 1.0F);
                }
            }
            if (!creative) stack.shrink(1);
        }
        return stack;
    }

    @Override
    public void releaseUsing(ItemStack stack, Level level, LivingEntity entity, int timeLeft) {
        // Cancelled half way: zip the vest back up.
        if (!level.isClientSide) {
            level.playSound(null, entity.getX(), entity.getY() + 1.0, entity.getZ(),
                    ModSounds.ZIP.get(), SoundSource.PLAYERS, 0.7F, 1.1F);
        }
    }

    // ------------------------------------------------------------------
    // First-person plating animation (client only)
    // ------------------------------------------------------------------
    @Override
    public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(new IClientItemExtensions() {
            @Override
            public boolean applyForgeHandTransform(PoseStack pose, LocalPlayer player, HumanoidArm arm,
                                                   ItemStack stack, float partialTick, float equipProcess,
                                                   float swingProcess) {
                if (!player.isUsingItem() || player.getUseItem() != stack) return false;

                int side = arm == HumanoidArm.RIGHT ? 1 : -1;
                float total = Config.PLATE_USE_TICKS.get();
                float used = total - player.getUseItemRemainingTicks() + partialTick;
                float t = Mth.clamp(used / total, 0.0F, 1.0F);

                // vanilla resting position
                pose.translate(side * 0.56F, -0.52F + equipProcess * -0.6F, -0.72F);

                // 0 -> 1 as the plate is brought to the vest, back to 0 for the hand pull-out
                float bring = smooth(t / 0.16F) * (1.0F - smooth((t - 0.86F) / 0.14F));
                // 0 -> 1 while it is being pushed in
                float push = Mth.clamp((t - 0.22F) / 0.5F, 0.0F, 1.0F);
                float wiggle = Mth.sin(t * 38.0F) * 0.012F * bring * (push > 0.0F && push < 1.0F ? 1.0F : 0.0F);

                pose.translate(-side * 0.46F * bring + wiggle,
                               (-0.34F - 0.20F * push) * bring,
                               0.10F * bring);
                pose.mulPose(Axis.XP.rotationDegrees(-58.0F * bring));
                pose.mulPose(Axis.ZP.rotationDegrees(side * -24.0F * bring));
                pose.mulPose(Axis.YP.rotationDegrees(side * 18.0F * bring));
                return true;
            }

            private float smooth(float x) {
                x = Mth.clamp(x, 0.0F, 1.0F);
                return x * x * (3.0F - 2.0F * x);
            }
        });
    }
}
