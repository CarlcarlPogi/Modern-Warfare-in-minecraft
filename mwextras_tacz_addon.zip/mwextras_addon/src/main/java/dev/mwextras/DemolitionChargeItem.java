package dev.mwextras;

import java.util.function.Consumer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;

import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;

/** Hold right click while aiming at the ground: keypad beeps, you are rooted, then the bomb is armed. */
public class DemolitionChargeItem extends Item {

    public DemolitionChargeItem(Properties props) {
        super(props);
    }

    @Override public int getUseDuration(ItemStack stack) { return Config.BOMB_PLANT_TICKS.get(); }
    @Override public UseAnim getUseAnimation(ItemStack stack) { return UseAnim.CUSTOM; }

    private BlockHitResult groundHit(Level level, Player player) {
        return getPlayerPOVHitResult(level, player, ClipContext.Fluid.NONE);
    }

    private boolean validSpot(BlockHitResult hit) {
        return hit.getType() == HitResult.Type.BLOCK && hit.getDirection() == Direction.UP;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!validSpot(groundHit(level, player))) {
            if (!level.isClientSide) player.displayClientMessage(Component.literal("Aim at the ground to plant the bomb"), true);
            return InteractionResultHolder.fail(stack);
        }
        player.startUsingItem(hand);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public void onUseTick(Level level, LivingEntity entity, ItemStack stack, int remaining) {
        if (level.isClientSide) return;
        // rooted in place while planting
        entity.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 4, 6, false, false, false));

        int total = getUseDuration(stack);
        int used = total - remaining;
        if (used > 0 && used % 8 == 0 && used < total - 6) {
            level.playSound(null, entity.getX(), entity.getY() + 0.5, entity.getZ(), ModSounds.KEYPAD.get(),
                    SoundSource.PLAYERS, 0.8F, 0.85F + 0.07F * (used / 8));
        }
        // looked away from the ground: cancel
        if (entity instanceof Player p && !validSpot(groundHit(level, p))) {
            entity.stopUsingItem();
            p.displayClientMessage(Component.literal("Plant cancelled"), true);
        }
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        if (!(entity instanceof Player player)) return stack;
        if (!level.isClientSide && player instanceof ServerPlayer sp) {
            BlockHitResult hit = groundHit(level, sp);
            if (validSpot(hit)) {
                var pos = hit.getLocation();
                level.addFreshEntity(new PlantedBomb(level, pos.x, pos.y, pos.z, sp, sp.getYRot() + 180.0F));
                level.playSound(null, pos.x, pos.y, pos.z, ModSounds.ARM.get(), SoundSource.PLAYERS, 1.5F, 1.0F);
                Announcer.toAll(sp.server, ModSounds.VOICE_PLANTED.get(),
                        Component.literal("\u00a7cBOMB PLANTED"),
                        Component.literal("\u00a77Defuse it before it detonates"));
                if (!sp.getAbilities().instabuild) stack.shrink(1);
            }
        } else if (level.isClientSide && !player.getAbilities().instabuild) {
            stack.shrink(1);
        }
        return stack;
    }

    // ------------------------------------------------------------------
    // Plant animation: raise the charge to the chest, tip it toward the ground,
    // press the keypad on each beep, then lower it onto the floor.
    // ------------------------------------------------------------------
    @Override
    public void initializeClient(Consumer<IClientItemExtensions> consumer) {
        consumer.accept(new IClientItemExtensions() {
            @Override
            public boolean applyForgeHandTransform(PoseStack pose, LocalPlayer player, HumanoidArm arm,
                                                   ItemStack stack, float pt, float equip, float swing) {
                int side = arm == HumanoidArm.RIGHT ? 1 : -1;
                pose.translate(side * 0.56F, -0.52F + equip * -0.6F, -0.72F);
                if (!player.isUsingItem() || player.getUseItem() != stack) return true;

                float total = Config.BOMB_PLANT_TICKS.get();
                float used = total - player.getUseItemRemainingTicks() + pt;
                float t = Mth.clamp(used / total, 0.0F, 1.0F);

                float bring = smooth(t / 0.14F) * (1.0F - smooth((t - 0.93F) / 0.07F));
                float place = smooth((t - 0.84F) / 0.16F);

                float bump = 0.0F;                       // keypad presses line up with the beeps
                for (int k = 1; k <= 7; k++) {
                    float d = Math.abs(used - k * 8.0F);
                    bump += Math.max(0.0F, 1.0F - d / 1.6F);
                }

                pose.translate(-side * 0.50F * bring,
                        (0.02F - 0.04F * bump) * bring - 0.20F * place,
                        0.22F * bring - 0.12F * place);
                pose.mulPose(Axis.XP.rotationDegrees(30.0F * bring + 24.0F * place));
                pose.mulPose(Axis.YP.rotationDegrees(side * 14.0F * bring));
                return true;
            }

            private float smooth(float x) {
                x = Mth.clamp(x, 0.0F, 1.0F);
                return x * x * (3.0F - 2.0F * x);
            }
        });
    }
}
