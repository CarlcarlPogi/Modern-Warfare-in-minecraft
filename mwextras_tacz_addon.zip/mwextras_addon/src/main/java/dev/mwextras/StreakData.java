package dev.mwextras;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.network.PacketDistributor;

public class StreakData {
    private static final String K = "mwextras_kills", U = "mwextras_used";

    public static int kills(Player p) {
        return p.level().isClientSide ? StreakClientCache.kills : p.getPersistentData().getInt(K);
    }
    public static int used(Player p) {
        return p.level().isClientSide ? StreakClientCache.usedMask : p.getPersistentData().getInt(U);
    }
    public static void set(ServerPlayer p, int kills, int used) {
        p.getPersistentData().putInt(K, kills);
        p.getPersistentData().putInt(U, used);
    }
    public static boolean ready(Player p, Streak s) {
        return kills(p) >= s.kills && (used(p) & (1 << s.ordinal())) == 0;
    }
    /** event: 0 = silent sync, 1 = streak unlocked (slot), 2 = streak activated (slot). */
    public static void sync(ServerPlayer p, int event, int slot) {
        Net.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p),
                new StreakPacket(kills(p), used(p), event, slot));
    }
}
