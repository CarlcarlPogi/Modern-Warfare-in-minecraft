package dev.mwextras;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Container;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public class StreakActions {

    public static void activateSlot(ServerPlayer sp, int slot) {
        Streak[] all = Streak.values();
        if (slot < 0 || slot >= all.length) return;
        activate(sp, all[slot], null);
    }

    /** held = the card stack being right-clicked, or null when triggered from a key. */
    public static void activate(ServerPlayer sp, Streak s, ItemStack held) {
        if (!StreakData.ready(sp, s)) {
            int have = StreakData.kills(sp);
            boolean used = (StreakData.used(sp) & (1 << s.ordinal())) != 0;
            sp.displayClientMessage(Component.literal(used
                    ? s.displayName + " already used this life"
                    : s.displayName + " needs " + s.kills + " kills (" + have + "/" + s.kills + ")"), true);
            return;
        }

        // consume the card
        if (held != null && held.is(s.item())) {
            held.shrink(1);
        } else {
            for (int i = 0; i < sp.getInventory().getContainerSize(); i++) {
                ItemStack st = sp.getInventory().getItem(i);
                if (st.is(s.item())) { st.shrink(1); break; }
            }
        }

        StreakData.set(sp, StreakData.kills(sp), StreakData.used(sp) | (1 << s.ordinal()));
        StreakData.sync(sp, 2, s.ordinal());
        sp.playNotifySound(ModSounds.STREAK_USE.get(), SoundSource.PLAYERS, 1.0F, 1.0F);
        sp.playNotifySound(s.voice(), SoundSource.PLAYERS, 1.0F, 1.0F);

        switch (s) {
            case UAV -> uav(sp);
            case CARE_PACKAGE -> carePackage(sp);
            case CLUSTER_STRIKE -> clusterStrike(sp);
        }
    }

    // ---------------------------------------------------------------- UAV
    private static void uav(ServerPlayer sp) {
        ServerLevel level = sp.serverLevel();
        var box = sp.getBoundingBox().inflate(Config.UAV_RANGE.get());
        int ticks = Config.UAV_SECONDS.get() * 20;
        int n = 0;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box,
                x -> x != sp && (x instanceof Player || x instanceof Enemy))) {
            e.addEffect(new MobEffectInstance(MobEffects.GLOWING, ticks, 0, false, false));
            n++;
        }
        sp.displayClientMessage(Component.literal("UAV online - " + n + " contacts marked"), true);
    }

    // ---------------------------------------------------------------- Care package
    private static void carePackage(ServerPlayer sp) {
        ServerLevel level = sp.serverLevel();
        Vec3 look = sp.getLookAngle();
        BlockPos base = BlockPos.containing(sp.getX() + look.x * 4.0, sp.getY(), sp.getZ() + look.z * 4.0);
        BlockPos ground = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING, base);

        // coloured smoke marker for 3 seconds, then the crate lands
        for (int i = 0; i < 12; i++) {
            Scheduler.later(i * 5, () -> level.sendParticles(ParticleTypes.CAMPFIRE_SIGNAL_SMOKE,
                    ground.getX() + 0.5, ground.getY() + 0.3, ground.getZ() + 0.5, 6, 0.2, 0.1, 0.2, 0.02));
        }
        Scheduler.later(60, () -> {
            level.setBlock(ground, Blocks.BARREL.defaultBlockState().setValue(BlockStateProperties.FACING, Direction.UP), 3);
            BlockEntity be = level.getBlockEntity(ground);
            if (be instanceof Container c) {
                put(c, 0, new ItemStack(ModItems.ARMOR_PLATE.get(), 3));
                put(c, 1, new ItemStack(ModItems.THROWING_KNIFE.get(), 4));
                put(c, 2, new ItemStack(Items.GOLDEN_APPLE, 2));
                put(c, 3, new ItemStack(Items.COOKED_BEEF, 8));
            }
            level.playSound(null, ground, SoundEvents.ANVIL_LAND, SoundSource.BLOCKS, 1.0F, 0.8F);
            level.sendParticles(ParticleTypes.FIREWORK, ground.getX() + 0.5, ground.getY() + 1.0, ground.getZ() + 0.5,
                    30, 0.4, 0.5, 0.4, 0.05);
        });
        sp.displayClientMessage(Component.literal("Care Package inbound - follow the smoke"), true);
    }

    private static void put(Container c, int slot, ItemStack st) {
        if (slot < c.getContainerSize()) c.setItem(slot, st);
    }

    // ---------------------------------------------------------------- Cluster strike
    private static void clusterStrike(ServerPlayer sp) {
        ServerLevel level = sp.serverLevel();
        HitResult hit = sp.pick(96.0, 1.0F, false);
        Vec3 target = hit.getLocation();
        var marker = new DustParticleOptions(new org.joml.Vector3f(1.0F, 0.1F, 0.1F), 2.0F);

        for (int i = 0; i < 14; i++) {
            Scheduler.later(i * 5, () -> level.sendParticles(marker, target.x, target.y + 0.2, target.z,
                    10, 0.6, 0.1, 0.6, 0.0));
        }
        level.playSound(null, BlockPos.containing(target), SoundEvents.FIREWORK_ROCKET_LAUNCH, SoundSource.PLAYERS, 3.0F, 0.5F);

        for (int i = 0; i < 7; i++) {
            final double ox = (level.random.nextDouble() - 0.5) * 12.0;
            final double oz = (level.random.nextDouble() - 0.5) * 12.0;
            Scheduler.later(60 + i * 7, () -> {
                double x = target.x + ox, z = target.z + oz;
                double y = level.getHeight(Heightmap.Types.MOTION_BLOCKING, (int) Math.floor(x), (int) Math.floor(z));
                level.explode(sp, x, y, z, 2.8F, Config.STREAK_BLOCK_DAMAGE.get()
                        ? Level.ExplosionInteraction.TNT : Level.ExplosionInteraction.NONE);
            });
        }
        sp.displayClientMessage(Component.literal("Cluster Strike inbound - clear the area"), true);
    }
}
